import Vue from 'vue'
import App from './App.vue'
import router from './router/index.js'
//import store from './store'

Vue.config.productionTip = false

// 功能一：引入和配置mint-ui组件库
// 1：引入mint-ui所有组件
import MintUI from "mint-ui"
// 2：单独引入mint-ui样式文件
import "mint-ui/lib/style.css"
// 3：将mint-ui对象注册Vue实例
Vue.use(MintUI);

// 功能二：引入图标字体样式文件，使所有自定义组都可以使用
import "./font/iconfont.css"

//功能三：引入axios库
// 1：引入axios库
import axios from "axios"
// 2：配置访问服务器基础路径
//axios.defaults.baseURL="http://127.0.0.1:4000/"
axios.defaults.baseURL="http://172.16.22.23:4000/"
// 3：配置保留session数据
axios.defaults.withCredentials=true
// 4：注册
Vue.prototype.axios = axios;

new Vue({
  router,
  render: h => h(App),
  // store        // 4：将储存对象添加vue实例中
}).$mount('#app')
